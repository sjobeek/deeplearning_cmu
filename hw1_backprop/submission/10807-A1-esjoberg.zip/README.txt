To view the output of the code, please open hw1_code_submission.ipynb using the Ipython/Jupyter Notebook. 

Instructions are contained inside. This code was written targetting Python 3.5



The implementation is contained inside of nn_backprop.py. 

The Simple results can also be obtained at the terminal by running the following: 

python nn_backprop.py